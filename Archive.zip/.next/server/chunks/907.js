exports.id = 907;
exports.ids = [907];
exports.modules = {

/***/ 1955:
/***/ ((module) => {

// Exports
module.exports = {
	"Header": "Header_Header__N4M24",
	"header__logoImg": "Header_header__logoImg__SXU3Z",
	"header__links": "Header_header__links__1d9r8",
	"header__nav": "Header_header__nav__p8XoQ",
	"header__right": "Header_header__right__2J0nY",
	"header__link--hidden": "Header_header__link--hidden__Krue0",
	"header__menu": "Header_header__menu__OJEH7",
	"MuiSvgIcon-root": "Header_MuiSvgIcon-root__ktkDm",
	"header": "Header_header__l1qoc"
};


/***/ }),

/***/ 1469:
/***/ ((module) => {

// Exports
module.exports = {
	"menu": "Menu_menu__Acgsz",
	"menuItem": "Menu_menuItem__Ruux4",
	"h4": "Menu_h4__oq2pm"
};


/***/ }),

/***/ 5405:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ components_Header)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./components/Header.module.css
var Header_module = __webpack_require__(1955);
var Header_module_default = /*#__PURE__*/__webpack_require__.n(Header_module);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
// EXTERNAL MODULE: external "@mui/icons-material/Menu"
var Menu_ = __webpack_require__(3365);
var Menu_default = /*#__PURE__*/__webpack_require__.n(Menu_);
// EXTERNAL MODULE: external "@mui/icons-material/Close"
var Close_ = __webpack_require__(4173);
var Close_default = /*#__PURE__*/__webpack_require__.n(Close_);
;// CONCATENATED MODULE: ./public/img/Logo SMP White.png
/* harmony default export */ const Logo_SMP_White = ({"src":"/_next/static/media/Logo SMP White.8d7a9399.png","height":230,"width":641,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAADCAYAAACuyE5IAAAAYklEQVR4nGP89++fOAMDAy8QM/z/8eM3Eyfnz6e2Tmrc+dkh/AEBS0AKlgDlVID4PRDfY2RkdPj56PGq9+2dQSItjV9ACiSAEsxAzPD3/YcvLEKCAS8rq16xGRq6CQQFLQcAVtcl8mQdKkAAAAAASUVORK5CYII="});
;// CONCATENATED MODULE: ./public/img/Logo SMP Black.png
/* harmony default export */ const Logo_SMP_Black = ({"src":"/_next/static/media/Logo SMP Black.7a91628d.png","height":230,"width":641,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAADCAYAAACuyE5IAAAAYUlEQVR4nGNkYGAQB2JeIGZwYmD8vS848OeRtevUdNauC+H19V0CUrAEiFWA+L0wA8O9t2KiDlGvXq+a3tgcxJ6Z/gWkQAKImYGYIZaB+ctiTdWA7ddvvLJev8GNy8trOQD3ABziYtE10AAAAABJRU5ErkJggg=="});
;// CONCATENATED MODULE: ./components/Header.js









function Header({ isMenuOpen , setIsMenuOpen , backColor , valueSize , defaultBack ,  }) {
    const handleIcon = ()=>{
        if (defaultBack === 'black') {
            return isMenuOpen ? Logo_SMP_White : Logo_SMP_White;
        } else {
            return isMenuOpen ? Logo_SMP_Black : Logo_SMP_White;
        }
    };
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: (Header_module_default()).Header,
        style: isMenuOpen === false ? backColor ? {
            backgroundColor: 'rgba(0, 0, 0, 0.1)'
        } : {
            backgroundColor: 'rgba(0, 0, 0, 0.3)'
        } : {
            backgroundColor: 'rgba(0, 0, 0, 0.0)'
        },
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: (Header_module_default()).header__logo,
                children: /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                    href: "/",
                    passHref: true,
                    children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: (Header_module_default()).header__logoImg,
                        style: {
                            width: valueSize * 0.1
                        },
                        children: /*#__PURE__*/ jsx_runtime_.jsx(next_image["default"], {
                            src: handleIcon(),
                            alt: ""
                        })
                    })
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (Header_module_default()).header__links,
                children: [
                    !isMenuOpen && /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (Header_module_default()).header__links,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                className: (Header_module_default()).header__nav,
                                style: {
                                    fontSize: valueSize * 0.02
                                },
                                href: "/digitalization",
                                children: "DIGITALIZATION"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                className: (Header_module_default()).header__nav,
                                style: {
                                    fontSize: valueSize * 0.02
                                },
                                href: "/iot",
                                children: "IOT PLATFORM"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                className: (Header_module_default()).header__nav,
                                style: {
                                    fontSize: valueSize * 0.02
                                },
                                href: "/business-platform",
                                children: "BUSINESS PLATFORM"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                className: (Header_module_default()).header__nav,
                                style: {
                                    fontSize: valueSize * 0.02
                                },
                                href: "/support-service",
                                children: "PROFESIONAL SERVICES"
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: (Header_module_default()).header__menu,
                        onClick: ()=>setIsMenuOpen(!isMenuOpen)
                        ,
                        children: isMenuOpen ? /*#__PURE__*/ jsx_runtime_.jsx((Close_default()), {
                            style: {
                                fontSize: valueSize * 0.03
                            }
                        }) : /*#__PURE__*/ jsx_runtime_.jsx((Menu_default()), {
                            style: {
                                color: 'white',
                                fontSize: valueSize * 0.03
                            }
                        })
                    })
                ]
            })
        ]
    }));
}
/* harmony default export */ const components_Header = (Header);


/***/ }),

/***/ 9678:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1664);
/* harmony import */ var _Menu_module_css__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1469);
/* harmony import */ var _Menu_module_css__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_Menu_module_css__WEBPACK_IMPORTED_MODULE_3__);




function Menu({ valueSize  }) {
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: (_Menu_module_css__WEBPACK_IMPORTED_MODULE_3___default().menu),
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_link__WEBPACK_IMPORTED_MODULE_2__["default"], {
                href: "/pillar",
                passHref: true,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: (_Menu_module_css__WEBPACK_IMPORTED_MODULE_3___default().menuItem),
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h4", {
                        className: (_Menu_module_css__WEBPACK_IMPORTED_MODULE_3___default().h4),
                        style: {
                            fontSize: valueSize * 0.023
                        },
                        children: "Our Pilar"
                    })
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_link__WEBPACK_IMPORTED_MODULE_2__["default"], {
                href: "/",
                passHref: true,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: (_Menu_module_css__WEBPACK_IMPORTED_MODULE_3___default().menuItem),
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h4", {
                        className: (_Menu_module_css__WEBPACK_IMPORTED_MODULE_3___default().h4),
                        style: {
                            fontSize: valueSize * 0.023
                        },
                        children: "Blog"
                    })
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_link__WEBPACK_IMPORTED_MODULE_2__["default"], {
                href: "/contact-us",
                passHref: true,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: (_Menu_module_css__WEBPACK_IMPORTED_MODULE_3___default().menuItem),
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h4", {
                        className: (_Menu_module_css__WEBPACK_IMPORTED_MODULE_3___default().h4),
                        style: {
                            fontSize: valueSize * 0.023
                        },
                        children: "Contact Us"
                    })
                })
            })
        ]
    }));
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Menu);


/***/ })

};
;