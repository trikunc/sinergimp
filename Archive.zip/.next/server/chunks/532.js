exports.id = 532;
exports.ids = [532];
exports.modules = {

/***/ 2969:
/***/ ((module) => {

// Exports
module.exports = {
	"login": "login_login__4A4JY",
	"h2": "login_h2__ru8rK",
	"container": "login_container__TxgKQ",
	"section_title": "login_section_title__6rAWZ",
	"row": "login_row__c37Nu",
	"form_container": "login_form_container__kqdwc",
	"form": "login_form__98nlS",
	"form_row": "login_form_row__gKSMA",
	"form_group": "login_form_group__6XqCM",
	"form_button_container": "login_form_button_container__q9rFU",
	"form_button": "login_form_button___DN7M",
	"form_title": "login_form_title__nDUUI",
	"label": "login_label__S__zk",
	"input": "login_input__lcHTp",
	"info_container": "login_info_container__w5JT5"
};


/***/ }),

/***/ 1207:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/LogoCrop.ee4b31ae.png","height":230,"width":185,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAICAMAAADtGH4KAAAARVBMVEX////oc3XpcXXjIyvuoaLdAADYAADjFyLxt7j43t/43N3wtbbxubr55ebjIyv99vbjISrjISrgAAD//////v7jISrhAAAAbkCuAAAAE3RSTlMAAAAAAgg6VHeYm6ayuLq+xMX4qRbI4QAAACxJREFUeNpjYGfkYGViYRBl4+dlYGAQEOMW5mRgYOYT4hHhglGCYEGYEogGADS4AdrP9mgnAAAAAElFTkSuQmCC"});

/***/ })

};
;