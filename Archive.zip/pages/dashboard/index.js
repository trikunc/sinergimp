import Layout from '../../components/Layout/Layout.jsx';
import styles from './Dashboard.module.css';

const index = () => {
  return <Layout>Dashboard</Layout>;
};

export default index;
