module.exports = {
  /* config options here */
};

// const withImages = require('next-images');
// module.exports = require('next-images');

// module.exports = {
//   images: {
//     disableStaticImages: true,
//   },
// };
