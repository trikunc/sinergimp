module.exports = {
  // reactStrictMode: true,
};

// const withImages = require('next-images');
// module.exports = require('next-images');

// module.exports = {
//   images: {
//     disableStaticImages: true,
//   },
// };
